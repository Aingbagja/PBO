/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */
public class dr_strange extends avengers{
    String Karakter2;


public dr_strange(){
}
public String getKarakter2(){
    return Karakter2;
}
public void setKarakter2(String Karakter4){
    this.Karakter2 = Karakter2;
}

}