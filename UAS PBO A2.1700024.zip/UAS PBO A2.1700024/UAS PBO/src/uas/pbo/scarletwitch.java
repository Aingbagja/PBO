/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */public class scarletwitch extends avengers{
    String  Karakter5;
    
    public scarletwitch(){   
    }
   
    public String getKarakter5(){
     return Karakter5;
    }
    public void setKarakter5(String Karakter5){
        this.Karakter5 = Karakter5;
    }
    
}
