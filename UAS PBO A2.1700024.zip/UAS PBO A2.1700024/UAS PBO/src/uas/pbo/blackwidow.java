/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */
public class blackwidow extends avengers {
  String Karakter;
  
  public blackwidow(){   
  }
  public String getKarakter(){
      return Karakter;
  }
  public void setKarakter(String Karakter){
      this.Karakter = Karakter;
  }
}
