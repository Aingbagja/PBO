/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 * NAMA BAGJA SUMARLIN
 * NIM A2.1700024
 * TEKNIK INFORMATIKA J&S KARYAWAN
 */
public class UASPBO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
      //Dr.Strange
         blackwidow bw= new blackwidow();
        bw.setnamaAvengers("Black Widow");
        bw.setKarakter("\n Seseorang agen intelejen  \n" +
        "yang memiliki kemampuan beladiri tinggi\n" +
        "ahli pertempuran jarak dekan=t\n");
        System.out.println("nama avengers : "+bw.getnamaAvengers());
        System.out.println("karakter avengers : "+bw.getKarakter());
        
      //captamerica
        captain_america cp= new captain_america(); //cp adalah variabel yang diwakilkan dari class 
        cp.setnamaAvengers("captain america"); //memasukan nama
        cp.setKarakter1("Kekuatan, kelincahan, kecepatan, dan stamina diatas rata rata manusia normal\n" +
        "Menguasai bela diri, taktik, dan seorang penembak jitu\n" +
        "Memegang perisai dari logam Vibranium\n" +
        "Komandan lapangan yang sangat cerdas dan disiplin");
        System.out.println("nama avengers : "+cp.getnamaAvengers()); //memanggil nama
        System.out.println("karakter avengers : "+cp.getKarakter1()); //memanggil karakter
        
      //Dr.Strange
         dr_strange ds= new dr_strange();
        ds.setnamaAvengers("Dr.strange");
        ds.setKarakter2("\n Seseorang Dokter bedah yang menjadi penyihir \n" +
        "karena kecelakaan hebat dia bertemu dengan gurunya (acient one)\n" +
        "kemudian belajar berbagai macam sihir.\n" +
        "Dan menjadi pewarsi dari eye of agimoto");
        System.out.println("nama avengers : "+ds.getnamaAvengers());
        System.out.println("karakter avengers : "+ds.getKarakter2());
        
         //Groot
         groot gr= new groot();
        gr.setnamaAvengers("Groot");
        gr.setKarakter3("\n Alien dari luarangkasa berbentuk pohon \n" +
        "Ikut berjuang bersama guardian galaksi\n" +
        "Menjelajah alam semesta dengan team quil\n" +
        "Memiliki regenerasi yang tinggi");
        System.out.println("nama avengers : "+gr.getnamaAvengers());
        System.out.println("karakter avengers : "+gr.getKarakter3());
        
         //Ironman
         ironman ir= new ironman();
        ir.setnamaAvengers("Ironman");
        ir.setKarakter4("\n Si jenius yang playboy \n" +
        "pemilik stark industri penyelamat bumi\n" +
        "salah satu karakter paling di hormati di avengers\n" +
        "Dengan baju besi nya");
        System.out.println("nama avengers : "+ir.getnamaAvengers());
        System.out.println("karakter avengers : "+ir.getKarakter4());
        
            //Groot
         scarletwitch sc= new scarletwitch();
        sc.setnamaAvengers("Scarletwitch");
        sc.setKarakter5("\n Seorang mutan wanita yang menjadi kelinci percobaan \n" +
        "dan bergabung dengan avengers \n" +
        "memiliki ilmu telekenesis yang sangat kuat\n" +
        "dan sekarang bergabung dengan avengers");
        System.out.println("nama avengers : "+sc.getnamaAvengers());
        System.out.println("karakter avengers : "+sc.getKarakter5());
        
              //spiderman
         spiderman sp= new spiderman();
        sp.setnamaAvengers("Spiderman");
        sp.setKarakter6("\n Seseorang  yatim piatu yang jenius \n" +
        "tak sengaja terkena gigitan laba laba \n" +
        "dan menjadi spiderman yang di mentor oleh ironman\n" +
        "sejak ironman meninggal ,dia menjadi next ironman");
        System.out.println("nama avengers : "+sp.getnamaAvengers());
        System.out.println("karakter avengers : "+sp.getKarakter6());
        
              //thor
         thor th= new thor();
        th.setnamaAvengers("Thor");
        th.setKarakter7("\n Seorang dewa petir dari asgad \n" +
        "yang bergabung bersama avengers \n" +
        "adalah putra dari odin\n" +
        "dan menjadi raja asgad setelah odin meninggal");
        System.out.println("nama avengers : "+th.getnamaAvengers());
        System.out.println("karakter avengers : "+th.getKarakter7());
        
        //vision
     vision v= new vision();
        v.setnamaAvengers("Vision");
        v.setKarakter8("\n adalah AI Ciptaan ironman hulk dan thor \n" +
        "yang berubah menjadi manusia super setengah dewa \n" +
        "berkat kekuatan mind stone\n" +
        "memiliki kekuatan yang luar biasa");
        System.out.println("nama avengers : "+v.getnamaAvengers());
        System.out.println("karakter avengers : "+v.getKarakter8());
 
    }
    
}
