/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */
public class avengers {
    String namaAvengers;
    
public avengers (){
    
}
public String getnamaAvengers(){
    return namaAvengers;
}
public void setnamaAvengers(String namaAvengers){
    this.namaAvengers = namaAvengers;
}
}
