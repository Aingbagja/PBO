/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */public class vision extends avengers{
    String  Karakter8;
    
    public vision(){   
    }
   
    public String getKarakter8(){
     return Karakter8;
    }
    public void setKarakter8(String Karakter8){
        this.Karakter8 = Karakter8;
    }
    
}
