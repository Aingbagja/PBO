/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */public class groot extends avengers{
    String  Karakter3;
    
    public groot(){   
    }
   
    public String getKarakter3(){
     return Karakter3;
    }
    public void setKarakter3(String Karakter3){
        this.Karakter3 = Karakter3;
    }
    
}
