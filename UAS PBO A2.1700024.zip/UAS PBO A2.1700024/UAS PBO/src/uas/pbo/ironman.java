/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */
public class ironman extends avengers {
    String Karakter4;
    
public ironman(){
}

public String getKarakter4(){
    return Karakter4;
}
public void setKarakter4(String Karakter){
    this.Karakter4 = Karakter4;
}
}


