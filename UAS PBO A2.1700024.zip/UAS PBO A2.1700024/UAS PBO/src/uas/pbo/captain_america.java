/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */
public class captain_america extends avengers {
  String Karakter1;
  
  public captain_america(){   
  }
  public String getKarakter1(){
      return Karakter1;
  }
  public void setKarakter1(String Karakter1){
      this.Karakter1 = Karakter1;
  }
}
