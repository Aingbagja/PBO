/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */
public class spiderman extends avengers{
    String Karakter6;
    
    public spiderman(){    
    }
    
    public String getKarakter6(){
        return Karakter6;
    }
    public void setKarakter6(String Karakter3){
        this.Karakter6 = Karakter6;
    }
    
}
