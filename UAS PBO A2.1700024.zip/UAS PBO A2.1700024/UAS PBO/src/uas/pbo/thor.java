/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uas.pbo;

/**
 *
 * @author Aing
 */
public class thor extends avengers{
    String  Karakter7;
    
    public thor(){   
    }
   
    public String getKarakter7(){
     return Karakter7;
    }
    public void setKarakter7(String Karakter7){
        this.Karakter7 = Karakter7;
    }
    
}
