/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan60;

/**
 *
 * @author Aing
 */
public class deidara extends akatsuki {
    String katakatamutiara1;
    String kekuatan1;

public deidara(){
    
}
public String getkatakatamutiara1(){
    return katakatamutiara1;
}
public void setkatakatamutiara1(String katakatamutiara1){
    this.katakatamutiara1 = katakatamutiara1;
}
public String getkekuatan1(){
    return kekuatan1;
}
public void setkekuatan1(String kekuatan1){
    this.kekuatan1 = kekuatan1;
}
}
    

