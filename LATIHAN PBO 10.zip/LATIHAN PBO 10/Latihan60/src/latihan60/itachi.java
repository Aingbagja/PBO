/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan60;

/**
 *
 * @author Aing
 */
public class itachi extends akatsuki {
    String katakatamutiara2;
    String kekuatan2;

public itachi(){
    
}
public String getkatakatamutiara2(){
    return katakatamutiara2;
}
public void setkatakatamutiara2(String katakatamutiara2){
    this.katakatamutiara2 = katakatamutiara2;
}
public String getkekuatan2(){
    return kekuatan2;
}
public void setkekuatan2(String kekuatan2){
    this.kekuatan2 = kekuatan2;
}
}
