/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan59;

/**
 *
 * @author Aing
 */
public class Kogomouri extends conan {
        String karakter3;

public Kogomouri(){
    
}
public String getKarakter3(){
    return karakter3;
}
public void setKarakter3(String karakter3){
    this.karakter3 = karakter3 ;
}
}
