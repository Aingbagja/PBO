/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan59;

/**
 *
 * @author Aing
 */
public class RanMouri extends conan {
    String karakter2;

public RanMouri(){
    
}
public String getKarakter2(){
    return karakter2;
}
public void setKarakter2(String karakter2){
    this.karakter2 = karakter2 ;
}

}
