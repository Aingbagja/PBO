/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan58;

/**
 *
 * @author Aing
 */
public class JumlahBilangan extends Bilangan {
    public void tampilHasilJumlah(){
        int a,b;
        a=getX();
        b=getY();
        System.out.println("Hasil penjumlahan = "+(a+b));
        
    }
}
